import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-steppers',
  templateUrl: './steppers.component.html',
  styleUrls: ['./steppers.component.scss']
})
export class SteppersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
