export class Student {
    _id: number;
    student_name: String;
    student_email: String;
    section: String;
    subjects:any;
    dob: any;
    gender: String;
    mailStatus:string;
 }